chrome.runtime.sendMessage('',{
	type: 'notification',
	options: {
		title: 'R47 - Remote 4dministration 700ls',
		message: 'Welcome to my R47 app. This is the POC of possible Account Take Over by using unauth installed Chrome extension.',
		iconUrl: '/blekhet.png',
		type: 'basic'
	}
});

